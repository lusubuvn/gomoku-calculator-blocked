<template>
  <div class="game">
    <div class="board-box">
      <Board ref="board" :is-ai-turn="isAITurn" :preview-pv="previewPv" :block-mode="blockMode" @clicked="clicked" @toggle-blocked="toggleBlocked"></Board>
<div class="mobile-control-bar">
  <button class="mobile-tool" @click="newGame">🗎</button>

  <button class="mobile-tool"
    :disabled="position.length == 0"
    @click="checkThinking().then(() => backToBegin())">
    ⏮
  </button>

  <button class="mobile-tool"
    :disabled="position.length == 0"
    @click="checkThinking().then(() => { backward(); clearUsedTime() })">
    ◀
  </button>

  <button class="mobile-tool"
    :disabled="position.length == lastPosition.length"
    @click="checkThinking().then(() => forward())">
    ▶
  </button>

  <button class="mobile-tool"
    :disabled="position.length == lastPosition.length"
    @click="checkThinking().then(() => forwardToEnd())">
    ⏭
  </button>

  <button class="mobile-tool"
    :disabled="thinking || gameEnded || !ready"
    @click="startThink">
    ▶
  </button>

  <button class="mobile-tool"
    :disabled="!thinking"
    @click="stop">
    ■
  </button>

  <button class="mobile-tool"
    :disabled="thinking || !ready || gameEnded"
    @click="showBalanceOptions = true">
    ◐
  </button>

  <button
    class="mobile-tool"
    :class="{ 'mobile-lock-active': blockMode }"
    :disabled="thinking || !ready"
    @click="toggleBlockMode">
    {{ blockMode ? '🔓' : '🔒' }}
  </button>

  <button
    v-if="blocked.length > 0"
    class="mobile-tool mobile-clear"
    :disabled="thinking || !ready"
    @click="clearBlockedCells">
    🧹
  </button>

  <button class="mobile-tool" @click="showScreenshotOptions = true">
    🖼
  </button>

  <button class="mobile-tool" :disabled="imageImportBusy" @click="chooseImageForImport">
    📷
  </button>

  <button class="mobile-tool" @click="setValue({
    key: 'indexOrigin',
    value: indexOrigin == 0 ? position.length : 0
  })">
    ℹ
  </button>

  <button class="mobile-tool" @click="checkThinking().then(() => rotate())">
    ↻
  </button>

  <button class="mobile-tool" @click="checkThinking().then(() => { showFlipOptions = true })">
    ⇄
  </button>

  <button class="mobile-tool" @click="checkThinking().then(() => { showMoveOptions = true })">
    ↕
  </button>
</div>
      <div class="button-box">
        <scroller lock-y :scrollbar-x="$store.state.screenWidth < buttonBarWidth" :bounce="false">
          <div class="button-box" :style="{ width: `${buttonBarWidth}px` }">
            <flexbox :gutter="0">
              <flexbox-item>
                <x-button @click.native="newGame" style="padding: 0">
                  <i class="fa fa-file-o" aria-hidden="true"></i>
                </x-button>
              </flexbox-item>
              <flexbox-item>
                <x-button :disabled="position.length == 0" style="padding: 0" @click.native="() => {
                  checkThinking().then(() => {
                    backToBegin()
                  })
                }
                  ">
                  <i class="fa fa-angle-double-left fa-lg" aria-hidden="true"></i>
                </x-button>
              </flexbox-item>
              <flexbox-item>
                <x-button :disabled="position.length == 0" style="padding: 0" @click.native="() => {
                  checkThinking().then(() => {
                    backward()
                    clearUsedTime()
                  })
                }
                  ">
                  <i class="fa fa-angle-left fa-lg" aria-hidden="true"></i>
                </x-button>
              </flexbox-item>
              <flexbox-item>
                <x-button :disabled="position.length == lastPosition.length" style="padding: 0" @click.native="() => {
                  checkThinking().then(() => {
                    forward()
                  })
                }
                  ">
                  <i class="fa fa-angle-right fa-lg" aria-hidden="true"></i>
                </x-button>
              </flexbox-item>
              <flexbox-item>
                <x-button :disabled="position.length == lastPosition.length" style="padding: 0" @click.native="() => {
                  checkThinking().then(() => {
                    forwardToEnd()
                  })
                }
                  ">
                  <i class="fa fa-angle-double-right fa-lg" aria-hidden="true"></i>
                </x-button>
              </flexbox-item>
              <flexbox-item>
                <x-button v-if="!ready" style="padding: 0" @click.native="showLoading = true">
                  <i class="fa fa-spinner fa-spin"></i>
                </x-button>
                <x-button v-else :disabled="thinking || gameEnded" style="padding: 0" @click.native="startThink">
                  <i v-if="thinking" class="fa fa-cog fa-spin"></i>
                  <i v-else class="fa fa-play" :style="{
                    color: gameEnded ? '#145A32' : '#229954',
                  }"></i>
                </x-button>
              </flexbox-item>
              <flexbox-item>
                <x-button :disabled="!thinking" style="padding: 0" @click.native="stop">
                  <i class="fa fa-stop" :style="{ color: thinking ? '#E74C3C' : '#78281F' }"></i>
                </x-button>
              </flexbox-item>
              <flexbox-item>
                <x-button :disabled="thinking || !ready || gameEnded" style="padding: 0" @click.native="() => {
                  showBalanceOptions = true
                }
                  ">
                  <i class="fa fa-adjust" :style="{
                    color: thinking || !ready || gameEnded ? '#1A5276' : '#3498DB',
                  }"></i>
                </x-button>
              </flexbox-item>
              <flexbox-item>
                <x-button :disabled="thinking || !ready" style="padding: 0" @click.native="toggleBlockMode">
                  <i :class="blockMode ? 'fa fa-unlock' : 'fa fa-lock'" :style="{
                    color: blockMode ? '#E67E22' : '#566573',
                  }"></i>
                </x-button>
              </flexbox-item>
              <flexbox-item v-if="blocked.length > 0">
                <x-button :disabled="thinking || !ready" style="padding: 0" @click.native="clearBlockedCells">
                  <i class="fa fa-eraser" style="color: #C0392B"></i>
                </x-button>
              </flexbox-item>

              <flexbox-item :span="1 / 40" style="min-width: 0px"></flexbox-item>

              <flexbox-item>
                <x-button style="padding: 0" @click.native="() => {
                  showScreenshotOptions = true
                }
                  ">
                  <i class="fa fa-picture-o" aria-hidden="true"></i>
                </x-button>
              </flexbox-item>
              <flexbox-item>
                <x-button style="padding: 0" :disabled="imageImportBusy" @click.native="chooseImageForImport">
                  <i class="fa fa-camera" aria-hidden="true"></i>
                </x-button>
              </flexbox-item>
              <flexbox-item>
                <x-button style="padding: 0" @click.native="() => {
                  setValue({
                    key: 'indexOrigin',
                    value: indexOrigin == 0 ? position.length : 0,
                  })
                }
                  ">
                  <i v-if="indexOrigin == 0" class="fa fa-info-circle" aria-hidden="true"></i>
                  <i v-else class="fa fa-info" aria-hidden="true"></i>
                </x-button>
              </flexbox-item>

              <flexbox-item :span="1 / 40" style="min-width: 0px"></flexbox-item>

              <flexbox-item>
                <x-button style="padding: 0" @click.native="() => {
                  checkThinking().then(() => {
                    rotate()
                  })
                }
                  ">
                  <i class="fa fa-repeat"></i>
                </x-button>
              </flexbox-item>
              <flexbox-item>
                <x-button style="padding: 0" @click.native="() => {
                  checkThinking().then(() => {
                    showFlipOptions = true
                  })
                }
                  ">
                  <i class="fa fa-exchange"></i>
                </x-button>
              </flexbox-item>
              <flexbox-item>
                <x-button style="padding: 0" @click.native="() => {
                  checkThinking().then(() => {
                    showMoveOptions = true
                  })
                }
                  ">
                  <i class="fa fa-arrows"></i>
                </x-button>
              </flexbox-item>
            </flexbox>
          </div>
        </scroller>
      </div>
    </div>

    <load-more :show-loading="false" background-color="#fbf9fe" class="seperator"></load-more>

    <div class="info-box" :style="showAnalysis ? {} : { display: 'none' }">
      <div>
        <x-progress v-if="thinking && aiTimeUsed > 0 && turnTime != 0"
          :percent="Math.min((100 * aiTimeUsed) / Math.min(turnTime, matchTime), 100)"
          :show-cancel="false"></x-progress>

        <!-- 单点分析的信息输出 -->
        <x-table v-if="nbest == 1" :cell-bordered="true" style="background-color: #fff; line-height: 210%">
          <thead>
            <tr style="background-color: #f7f7f7">
              <th>{{ $t('game.info.depth') }}</th>
              <th>{{ $t('game.info.eval') }}</th>
              <th>{{ $t('game.info.speed') }}</th>
              <th>{{ $t('game.info.nodes') }}</th>
              <th>{{ $t('game.info.time') }}</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>{{ outputs.pv[0].depth + '-' + outputs.pv[0].seldepth }}</td>
              <td style="font-weight: bold">{{ outputs.pv[0].eval }}</td>
              <td>{{ getSpeedText(outputs.speed) }}</td>
              <td>{{ getNodesText(outputs.nodes) }}</td>
              <td>{{ getTimeText(outputs.time) }}</td>
            </tr>
            <tr>
              <td colspan="5">
                <flexbox align="stretch" :gutter="0" style="padding: 5px">
                  <flexbox-item style="
                      padding: 2px 10px 2px 0;
                      width: initial;
                      line-height: initial;
                      flex: none;
                    ">
                    {{ $t('game.info.bestline') }}
                  </flexbox-item>
                  <flexbox-item>
                    <Bestline :bestline="outputs.pv[0].bestline" :boardSize="boardSize"
                      v-on:pvPreview="(pv) => (previewPv = pv)" v-on:pvSet="setPvAsPosition"></Bestline>
                  </flexbox-item>
                </flexbox>
              </td>
            </tr>
          </tbody>
        </x-table>

        <!-- 多点分析的信息输出 -->
        <div v-else>
          <x-table :cell-bordered="true" style="background-color: #fff; line-height: 210%">
            <thead>
              <tr style="background-color: #f7f7f7">
                <th>{{ $t('game.info.speed') }}</th>
                <th>{{ $t('game.info.nodes') }}</th>
                <th>{{ $t('game.info.time') }}</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>{{ getSpeedText(outputs.speed) }}</td>
                <td>{{ getNodesText(outputs.nodes) }}</td>
                <td>{{ getTimeText(outputs.time) }}</td>
              </tr>
            </tbody>
          </x-table>
          <x-table :cell-bordered="true" style="background-color: #fff; line-height: 210%">
            <thead>
              <tr style="background-color: #f7f7f7">
                <th>{{ $t('game.info.nbestIndex') }}</th>
                <th>{{ $t('game.info.depth') }}</th>
                <th>{{ $t('game.info.eval') }}</th>
                <th>{{ $t('game.info.bestline') }}</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="i in Math.min(nbest, outputs.pv.length)" :key="i">
                <td style="min-width: 40px">{{ i }}</td>
                <td style="min-width: 55px">
                  {{ outputs.pv[i - 1].depth + '-' + outputs.pv[i - 1].seldepth }}
                </td>
                <td style="font-weight: bold; min-width: 55px">{{ outputs.pv[i - 1].eval }}</td>
                <td>
                  <Bestline :bestline="outputs.pv[i - 1].bestline" :boardSize="boardSize"
                    v-on:pvPreview="(pv) => (previewPv = pv)" v-on:pvSet="setPvAsPosition"></Bestline>
                </td>
              </tr>
            </tbody>
          </x-table>
        </div>
      </div>

      <group>
        <group-title slot="title">
          {{ $t('game.currentPos') }}
          <span v-if="clipboardAvailable" style="float:right;">
            <button class="icon-button" @click="copyPosStrToClipboard">
              <i class="fa fa-files-o" aria-hidden="true"></i>
            </button>
            <button class="icon-button" @click="pastePosStrFromClipboard">
              <i class="fa fa-clipboard" aria-hidden="true"></i>
            </button>
          </span>
        </group-title>
        <x-textarea ref="curposArea" :value="posStr" @on-change="(v) => { setPosStr(v) }" style="padding: 5px 12px"
          :show-counter="false" :rows="1" autosize></x-textarea>
      </group>

      <group :title="$t('game.evalChart')">
        <div :style="{ width: chartWidth + 'px', height: chartWidth * 0.6 + 'px' }">
          <v-chart ref="chart" :data="evalData" :width="chartWidth" :height="chartWidth * 0.6">
            <v-scale ref="chartx" x :tick-interval="2" />
            <v-scale y alias="eval" :tick-count="5" />
            <v-point :style="{ stroke: '#fff', lineWidth: 1 }" :size="5" shape="smooth" series-field="piece" />
            <v-line shape="smooth" series-field="piece" />
            <v-area shape="smooth" series-field="piece" />
          </v-chart>
        </div>
      </group>
    </div>

    <div v-transfer-dom>
      <actionsheet v-model="showBalanceOptions" :menus="balanceOptions" @on-click-menu="(key) => {
        if (key == 0 || key == 1) this.startThinkBalance(key + 1)
      }
        " show-cancel :cancel-text="$t('common.cancel')"></actionsheet>
    </div>

    <div v-transfer-dom>
      <actionsheet v-model="showFlipOptions" :menus="flipOptions" @on-click-menu="onFlipOption" show-cancel
        :cancel-text="$t('common.cancel')"></actionsheet>
    </div>

    <div v-transfer-dom>
      <actionsheet v-model="showMoveOptions" :menus="moveOptions" @on-click-menu="onMoveOption" show-cancel
        :cancel-text="$t('common.cancel')"></actionsheet>
    </div>

    <div v-transfer-dom>
      <actionsheet v-model="showScreenshotOptions" :menus="shotOptions" @on-click-menu="onScreenshotOption" show-cancel
        :cancel-text="$t('common.cancel')"></actionsheet>
    </div>

    <div v-transfer-dom>
      <popup v-model="showScreenshot" style="height: 50%" is-transparent>
        <div class="screenshot-box">
          <span v-if="gifLoading">
            {{ $t('game.gifLoading') }}
            <i class="fa fa-spinner fa-pulse fa-lg" aria-hidden="true" />
          </span>
          <img ref="screenshot" class="screenshot-img" />
          <x-button v-if="!gifLoading" type="primary" :disabled="isOnIOSBrowser" :plain="isOnIOSBrowser"
            :text="isOnIOSBrowser ? $t('game.saveScreenshotIOS') : $t('game.saveScreenshot')"
            @click.native="saveScreenshot"></x-button>
        </div>
      </popup>
    </div>

    <div v-transfer-dom>
      <x-dialog v-model="showImageImport" hide-on-blur>
        <div class="image-import-dialog">
          <h3>{{ $t('game.imageImport.title') }}</h3>
          <input ref="imageImportInput" type="file" accept="image/*" capture="environment" style="display:none" @change="onImageImportFile">
          <div v-if="imageImportPreview" class="image-import-preview">
            <img :src="imageImportPreview" alt="Ảnh bàn cờ">
          </div>
          <div v-if="imageImportBusy" class="image-import-status">
            <i class="fa fa-spinner fa-spin"></i> {{ $t('game.imageImport.processing') }}
          </div>
          <div v-if="imageImportError" class="image-import-error">{{ imageImportError }}</div>
          <div v-if="imageImportResult" class="image-import-info">
            <div><b>{{ $t('game.imageImport.board') }}:</b> {{ imageImportResult.boardSize }} × {{ imageImportResult.boardSize }}</div>
            <div><b>{{ $t('game.black') }}:</b> {{ imageImportResult.black.length }}</div>
            <div><b>{{ $t('game.white') }}:</b> {{ imageImportResult.white.length }}</div>
            <div><b>{{ $t('game.blockMode') }}:</b> {{ imageImportResult.blocked.length }}</div>
            <div class="image-import-note">{{ imageImportResult.warning || $t('game.imageImport.ready') }}</div>
          </div>
          <div class="image-import-buttons">
            <x-button @click.native="chooseImageForImport">{{ $t('game.imageImport.choose') }}</x-button>
            <x-button type="primary" :disabled="!imageImportResult || imageImportBusy" @click.native="applyImageImport">{{ $t('game.imageImport.apply') }}</x-button>
          </div>
        </div>
      </x-dialog>
    </div>

    <div v-transfer-dom>
      <x-dialog v-model="showLoading" hide-on-blur>
        <div style="margin:20px auto;">{{ $t('game.engineLoading') }}</div>
        <x-circle style="width: 100px;height: 100px;margin: 20px auto;" :percent="loadingProgress * 100"
          :stroke-width="6" :trail-width="6">
          <span style="color:#36D1DC">{{ Math.floor(loadingProgress * 10000) / 100 }}%</span>
        </x-circle>
        <div style="margin:10px auto;" @click="showLoading = false">
          <span class="vux-close"></span>
        </div>
      </x-dialog>
    </div>
  </div>
</template>

<script>
import {
  TransferDom,
  Flexbox,
  FlexboxItem,
  XButton,
  Scroller,
  LoadMore,
  XTable,
  XTextarea,
  Actionsheet,
  XProgress,
  Group,
  GroupTitle,
  Popup,
  VChart,
  VPoint,
  VLine,
  VScale,
  VArea,
  XDialog,
  XCircle,
  dateFormat,
} from 'vux'
import Board from '@/components/Board.vue'
import Bestline from '@/components/Bestline.vue'
import { mapState, mapGetters, mapMutations, mapActions } from 'vuex'
import { Promise } from 'q'
import { detectGomokuBoard } from '@/utils/imageBoardImport'

export default {
  name: 'game',
  directives: {
    TransferDom,
  },
  components: {
    Board,
    Bestline,
    Flexbox,
    FlexboxItem,
    XButton,
    Scroller,
    LoadMore,
    XTable,
    XTextarea,
    Actionsheet,
    XProgress,
    Group,
    GroupTitle,
    Popup,
    VChart,
    VPoint,
    VLine,
    VScale,
    VArea,
    XDialog,
    XCircle,
  },
  data: function () {
    return {
      aiTimeUsed: 0,
      showLoading: false,
      showBalanceOptions: false,
      showFlipOptions: false,
      showMoveOptions: false,
      showScreenshotOptions: false,
      showScreenshot: false,
      console: console,
      evalData: [
        { index: 0, eval: 0, piece: this.$t('game.black') },
        { index: 0, eval: 0, piece: this.$t('game.white') },
      ],
      thinkingCanceled: false,
      gifLoading: false,
      screenshotData: null,
      previewPv: null,
      clipboardAvailable: navigator.clipboard && window.isSecureContext,
      blockMode: false,
      showImageImport: false,
      imageImportBusy: false,
      imageImportError: '',
      imageImportPreview: '',
      imageImportResult: null,
    }
  },
  computed: {
    ...mapState(['screenWidth', 'screenHeight', 'isOnIOSBrowser']),
    ...mapState('settings', [
      'boardSize',
      'indexOrigin',
      'nbest',
      'aiThinkBlack',
      'aiThinkWhite',
      'showAnalysis',
    ]),
    ...mapState('ai', ['outputs', 'thinking', 'lastThinkTime', 'ready', 'loadingProgress']),
    ...mapState('position', ['position', 'lastPosition', 'winline', 'blocked']),
    ...mapGetters('settings', ['turnTime', 'matchTime']),
    ...mapGetters('ai', ['bestlineStr', 'bestline']),
    ...mapGetters('position', ['isEmpty', 'isBlocked', 'playerToMove', 'moveLeftCount', 'posStr']),
    buttonBarWidth() {
      const Width = 620
      if (this.screenWidth >= 1024)
        return Math.min(Width, Width + Math.max(0, this.screenWidth - 1024))
      else
        return Width
    },
    chartWidth() {
      if (this.screenWidth >= 1024 && this.screenWidth / this.screenHeight >= 4 / 3) {
        const MarginSum = 30 + 2 * Math.min(20, Math.max(0, 0.3 * this.screenWidth - 350))
        const MaxWidth = 600

        return Math.min(
          this.screenWidth -
          Math.max(this.$store.getters.boardCanvasWidth, this.buttonBarWidth) -
          MarginSum,
          MaxWidth
        )
      } else {
        return this.screenWidth
      }
    },
    bestline() {
      return this.bestlineStr(0)
    },
    balanceOptions() {
      return [this.$t('game.balance1'), this.$t('game.balance2')]
    },
    flipOptions() {
      return [
        this.$t('game.flip') + ' |',
        this.$t('game.flip') + ' -',
        this.$t('game.flip') + ' ╲',
        this.$t('game.flip') + ' ╱',
      ]
    },
    moveOptions() {
      return [
        this.$t('game.move') + ' ↑',
        this.$t('game.move') + ' ↓',
        this.$t('game.move') + ' ←',
        this.$t('game.move') + ' →',
      ]
    },
    shotOptions() {
      return [this.$t('game.shotJpg'), this.$t('game.shotGif')]
    },
    isAITurn() {
      return (
        (this.playerToMove == 'BLACK' && this.aiThinkBlack) ||
        (this.playerToMove == 'WHITE' && this.aiThinkWhite)
      )
    },
    gameEnded() {
      return this.winline.length > 0 || this.moveLeftCount == 0
    },
  },
  methods: {
    ...mapMutations('position', {
      newBoard: 'new',
    }),
    ...mapMutations('settings', ['setValue']),
    ...mapMutations('ai', ['clearUsedTime']),
    ...mapActions('position', [
      'setPosStr',
      'makeMove',
      'backToBegin',
      'backward',
      'forward',
      'forwardToEnd',
      'rotate',
      'flip',
      'moveTowards',
      'importBoard',
    ]),
    ...mapActions('position', {
      toggleBlockedAction: 'toggleBlocked',
      clearBlocked: 'clearBlocked',
    }),
    ...mapActions('ai', ['think', 'stop', 'restart']),

    checkThinking() {
      return new Promise((resolve) => {
        if (this.thinking) {
          this.$vux.confirm.show_i18n({
            title: this.$t('game.interruptThinking.title'),
            content: this.$t('game.interruptThinking.msg'),
            onCancel: () => { },
            onConfirm: () => {
              this.thinkingCanceled = true
              this.stop()
              resolve()
            },
          })
        } else resolve()
      })
    },

    onFlipOption(key) {
      switch (key) {
        case 0:
          this.flip([1, 0])
          break
        case 1:
          this.flip([0, 1])
          break
        case 2:
          this.flip([0, 0])
          break
        case 3:
          this.flip([1, 1])
          break
      }
    },

    onMoveOption(key) {
      switch (key) {
        case 0:
          this.moveTowards([0, -1])
          break
        case 1:
          this.moveTowards([0, 1])
          break
        case 2:
          this.moveTowards([-1, 0])
          break
        case 3:
          this.moveTowards([1, 0])
          break
      }
    },

    chooseImageForImport() {
      this.checkThinking().then(() => {
        this.imageImportError = ''
        if (this.$refs.imageImportInput) this.$refs.imageImportInput.value = ''
        this.$nextTick(() => {
          if (this.$refs.imageImportInput) this.$refs.imageImportInput.click()
        })
      })
    },

    async onImageImportFile(event) {
      const file = event.target.files && event.target.files[0]
      if (!file) return
      this.imageImportBusy = true
      this.imageImportError = ''
      this.imageImportResult = null
      this.imageImportPreview = ''
      this.showImageImport = true
      try {
        const result = await detectGomokuBoard(file, { maxDimension: 1800 })
        this.imageImportResult = result
        this.imageImportPreview = result.preview
      } catch (error) {
        this.imageImportError = error && error.message ? error.message : this.$t('game.imageImport.failed')
      } finally {
        this.imageImportBusy = false
      }
    },

    async applyImageImport() {
      if (!this.imageImportResult || this.imageImportBusy) return
      await this.checkThinking()
      const result = this.imageImportResult
      this.setValue({ key: 'boardSize', value: result.boardSize })
      this.importBoard(result)
      this.blockMode = false
      this.previewPv = null
      this.evalData = [
        { index: 0, eval: 0, piece: this.$t('game.black') },
        { index: 0, eval: 0, piece: this.$t('game.white') },
      ]
      this.showImageImport = false
      this.imageImportError = ''
      this.imageImportPreview = ''
      this.imageImportResult = null
      this.restart()
    },

    onScreenshotOption(key) {
      let _this = this
      let delayPrompt = this.$t('game.gifDelay')
      let startIndex, delay
      switch (key) {
        case 0:
          this.screenshotData = { url: this.$refs.board.screenshot(), ext: 'jpg' }
          this.$refs.screenshot.setAttribute('src', this.screenshotData.url)
          this.showScreenshot = true
          break
        case 1:
          _this.$vux.confirm.prompt_i18n('', {
            title: this.$t('game.gifStart'),
            inputAttrs: { type: 'number', min: 1, max: this.position.length },
            onShow() {
              _this.$vux.confirm.setInputValue('1')
            },
            onConfirm(v) {
              startIndex = +v
              if (isNaN(startIndex)) startIndex = 1
              startIndex = Math.max(0, Math.min(startIndex - 1, _this.position.length))
              _this.$vux.confirm.prompt_i18n('', {
                title: delayPrompt,
                inputAttrs: { type: 'number', min: 100 },
                onShow() {
                  _this.$vux.confirm.setInputValue('1000')
                },
                onConfirm(v) {
                  delay = +v
                  if (isNaN(delay)) delay = 1000
                  delay = Math.max(100, delay)
                  _this.gifLoading = true
                  _this.$refs.screenshot.setAttribute('src', '')
                  _this.showScreenshot = true
                  _this.$refs.board.exportGIF(startIndex, delay, (blob) => {
                    _this.gifLoading = false
                    _this.screenshotData = { url: URL.createObjectURL(blob), ext: 'gif' }
                    _this.$refs.screenshot.setAttribute('src', _this.screenshotData.url)
                  })
                },
              })
            },
          })
          break
      }
    },
    saveScreenshot() {
      function downloadBlobURL(blobUrl, name) {
        // Create a link element
        const link = document.createElement('a')

        // Set link's href to point to the Blob URL
        link.href = blobUrl
        link.download = name

        // Append link to the body
        document.body.appendChild(link)

        // Dispatch click event on the link
        // This is necessary as link.click() does not work on the latest firefox
        link.dispatchEvent(
          new MouseEvent('click', {
            bubbles: true,
            cancelable: true,
            view: window,
          })
        )

        // Remove link from body
        document.body.removeChild(link)
      }

      downloadBlobURL(
        this.screenshotData.url,
        `screenshot-${dateFormat(new Date(), 'YYYYMMDDHHmmss')}.${this.screenshotData.ext}`
      )
    },

    newGame() {
      this.checkThinking().then(() => {
        this.newBoard(this.boardSize)
        this.blockMode = false
        this.restart()
      })
    },

    toggleBlockMode() {
      this.checkThinking().then(() => {
        this.blockMode = !this.blockMode
      })
    },

    toggleBlocked(pos) {
      if (this.thinking || !this.ready) return
      if (this.isBlocked([pos.x, pos.y]) || this.isEmpty([pos.x, pos.y])) {
        this.toggleBlockedAction([pos.x, pos.y])
      }
    },

    clearBlockedCells() {
      this.clearBlocked()
      this.blockMode = false
    },

    clicked(e) {
      let pos = [e.x, e.y]
      if (this.thinking) return

      if (e.button == 0) {
        // 检查是否点击了棋盘上的棋子（任意棋子都可以触发AI推算）
        if (!this.isAITurn && !this.isEmpty(pos) && this.winline.length == 0) {
          // 点击了已下的棋子,触发AI推算
          this.startThink()
          return
        }

        if ((this.isEmpty(pos) && this.winline.length == 0) || this.isAITurn) {
          if (!this.isAITurn) {
            this.makeMove(pos)
          }
          if (this.isAITurn) this.startThink()
        }
      } else if (e.button == 2) {
        this.backward()
        this.clearUsedTime()
      }
    },

    startThink() {
      if (this.gameEnded) return

      this.think().then((pos) => {
        if (this.thinkingCanceled) {
          this.thinkingCanceled = false
          return
        }

        this.makeMove(pos)

        let e = +this.outputs.pv[0].eval
        if (!isNaN(e)) {
          this.evalData.push({
            index: this.position.length,
            eval: e,
            piece: this.playerToMove == 'BLACK' ? this.$t('game.white') : this.$t('game.black'),
          })
        }

        if (this.isAITurn) this.startThink()
      })
    },

    startThinkBalance(mode) {
      if (this.gameEnded) return

      this.think({ balanceMode: mode }).then((pos) => {
        if (this.thinkingCanceled) {
          this.thinkingCanceled = false
          return
        }

        this.makeMove(pos)
        if (mode == 2) {
          const pos2 = this.outputs.pv[0].bestline[1]
          this.makeMove(pos2)
        }
      })
    },

    setPvAsPosition(pv) {
      this.checkThinking().then(() => {
        let fullPosition = pv.position.concat(pv.pv)
        this.newBoard(this.boardSize)
        for (let pos of fullPosition) {
          if (!this.makeMove(pos)) break
        }
      })
    },

    getSpeedText(speed) {
      if (speed < 10000) {
        return speed.toString();
      } else if (speed < 100000000) {
        return Math.floor(speed / 1000) + "K";
      } else {
        return Math.floor(speed / 1000000) + "M";
      }
    },

    getNodesText(nodes) {
      if (nodes < 10000) {
        return nodes.toString();
      } else if (nodes < 10000000) {
        return Math.floor(nodes / 1000) + "K";
      } else if (nodes < 100000000000) {
        return Math.floor(nodes / 1000000) + "M";
      } else if (nodes < 100000000000000) {
        return Math.floor(nodes / 1000000000) + "G";
      } else {
        return Math.floor(nodes / 1000000000000) + "T";
      }
    },

    getTimeText(time) {
      if (time < 1000000) {
        return Math.floor(time / 1000) + "." + (Math.floor(time / 100) % 10) + "s";
      } else if (time < 360000000) {
        return Math.floor(time / 60000) + "min";
      } else {
        return Math.floor(time / 3600000) + "h";
      }
    },

    async copyPosStrToClipboard() {
      await navigator.clipboard.writeText(this.posStr);
      this.$vux.toast.text(this.$t('game.copiedToClipboard'))
    },

    async pastePosStrFromClipboard() {
      const posStr = await navigator.clipboard.readText();
      this.setPosStr(posStr)
    },
  },
  watch: {
    bestline: function () {
      if (this.$refs.bestlineArea) this.$refs.bestlineArea.updateAutosize()
    },
    posStr: function (newPos) {
      this.$refs.curposArea.updateAutosize()
      let oldIndex = this.evalData[this.evalData.length - 1].index
      let newIndex = Math.max(this.position.length, 1)
      if (newIndex < oldIndex) {
        for (let i = this.evalData.length - 1; i > 0; i--) {
          if (this.evalData[i].index > newIndex) this.evalData.pop()
        }
      }
      if (newPos.length > 0) this.$router.push({ name: 'game', params: { pos: newPos } })
      else this.$router.push({ name: 'game' })
    },
    boardSize: function (newSize) {
      if (this.thinking) this.stop()
      this.newBoard(newSize)
      this.restart()
    },
    loadingProgress: function (progress) {
      if (progress == 1) this.showLoading = false
    },
  },
  mounted() {
    this.newBoard(this.boardSize)
    if (this.$route.params.pos) this.setPosStr(this.$route.params.pos)

    window.addEventListener('keydown', (event) => {
      const target = event.target

      if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable)
        return
      if (event.repeat)
        return

      switch (event.key) {
        case 'ArrowLeft':
          this.checkThinking().then(() => this.backward())
          break
        case 'ArrowRight':
          this.checkThinking().then(() => this.forward())
          break
        case 'Home':
          this.checkThinking().then(() => this.backToBegin())
          break
        case 'End':
          this.checkThinking().then(() => this.forwardToEnd())
          break
        case ' ':
          if (this.thinking) this.stop()
          else if (this.ready && !this.gameEnded) this.startThink()
          break
        case 'b':
          this.checkThinking().then(() => this.startThinkBalance(1))
          break
        case 'B':
          this.checkThinking().then(() => this.startThinkBalance(2))
          break
      }
    })
    setInterval(() => {
      this.aiTimeUsed = this.thinking ? Date.now() - this.lastThinkTime : 0
    }, 100)
  },
}
</script>

<style lang="less" scoped>
.selectable {
  -webkit-user-select: text;
  -khtml-user-select: text;
  -moz-user-select: text;
  -ms-user-select: text;
  user-select: text;
}

.game {
  overflow-x: hidden;
}

.button-box {
  margin: auto;
  margin-top: ~'min(1vw, 10px)';
}

.seperator {
  margin-top: 20px;
  margin-bottom: 0px;
}

.image-import-dialog {
  margin: 0 auto;
  max-width: 520px;
  max-height: 88vh;
  overflow-y: auto;
  box-sizing: border-box;
  padding: 14px;
  background: #fff;
  border-radius: 8px;
  text-align: left;
}

.image-import-dialog h3 {
  margin: 0 0 12px;
  text-align: center;
}

.image-import-preview {
  width: 100%;
  background: #f5f5f5;
  border-radius: 6px;
  overflow: hidden;
  margin-bottom: 12px;
}

.image-import-preview img {
  display: block;
  width: 100%;
  height: auto;
}

.image-import-info {
  line-height: 1.9;
}

.image-import-status {
  text-align: center;
  padding: 12px 0;
}

.image-import-error {
  margin: 8px 0;
  padding: 8px;
  border-radius: 4px;
  background: #fdecea;
  color: #c0392b;
}

.image-import-note {
  margin-top: 8px;
  font-size: 13px;
  color: #566573;
}

.image-import-buttons {
  display: flex;
  gap: 8px;
  margin-top: 14px;
}

.image-import-buttons .weui-btn {
  flex: 1;
}

.screenshot-box {
  width: 95%;
  text-align: center;
  background-color: #fff;
  height: 95%;
  margin: 0 auto;
  border-radius: 5px;
  display: flex;
  flex-direction: column;
}

.screenshot-img {
  -webkit-touch-callout: default;
  flex: 1 1 auto;
  align-self: center;
  max-width: 100%;
  max-height: calc(100% - 42px);
}

@media (min-aspect-ratio: ~'4/3') and (min-width: 1024px) {
  .seperator {
    display: none !important;
  }

  .game {
    display: flex;
    flex-wrap: nowrap;
    justify-content: center;
    align-items: stretch;
  }

  .board-box {
    margin: 20px 10px;
  }

  @infobox-padding: ~'min(20px, max(30vw - 350px, 0px))';

  .info-box {
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    align-items: stretch;
    margin-top: 20px;
    margin-left: @infobox-padding;
    margin-right: calc(10px + @infobox-padding);
    padding-top: 10px;
    max-width: 600px;
  }
}

.loading-circle {
  width: 100px;
  height: 100px;
  margin: 20px auto;
}

.icon-button {
  background: none;
  border: none;
  padding: 0.1rem 0.25rem;
  border-radius: 0.1rem;
  transition: background-color 0.2s ease;
}

.icon-button:active {
  background-color: rgba(0, 0, 0, 0.2);
}

.icon-button i {
  font-size: 0.8rem;
  color: darkgray;
}

.icon-button:hover i {
  color: black;
}

.icon-button:active i {
  color: black;
}
  .mobile-control-bar {
  display: flex;
  gap: 6px;
  width: 100%;
  box-sizing: border-box;
  overflow-x: auto;
  padding: 8px 6px;
  background: #fff;
  -webkit-overflow-scrolling: touch;
}

.mobile-tool {
  flex: 0 0 44px;
  width: 44px;
  height: 40px;
  padding: 0;
  border: 1px solid #d0d0d0;
  border-radius: 5px;
  background: #fff;
  color: #333;
  font-size: 19px;
}

.mobile-tool:disabled {
  opacity: 0.4;
}

.mobile-lock-active {
  background: #e67e22;
  color: #fff;
}

.mobile-clear {
  color: #c0392b;
}

@media (min-width: 768px) {
  .mobile-control-bar {
    display: none;
  }
}
</style>
